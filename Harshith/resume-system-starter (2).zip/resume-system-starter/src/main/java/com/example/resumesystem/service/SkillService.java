package com.example.resumesystem.service;

import com.example.resumesystem.dto.SkillDTO;
import com.example.resumesystem.model.Skill;
import com.example.resumesystem.model.User;
import com.example.resumesystem.repository.SkillRepository;
import com.example.resumesystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SkillService {

    @Autowired
    private SkillRepository skillRepository;

    @Autowired
    private UserRepository userRepository;

    private User getAuthenticatedUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Skill createSkill(SkillDTO dto) {
        Skill skill = new Skill();
        skill.setName(dto.getName());
        skill.setLevel(dto.getLevel());
        skill.setUser(getAuthenticatedUser());
        return skillRepository.save(skill);
    }

    public List<Skill> getAllSkills() {
        return skillRepository.findByUser(getAuthenticatedUser());
    }

    public Skill updateSkill(Long id, SkillDTO dto) {
        Skill skill = skillRepository.findById(id).orElseThrow(() -> new RuntimeException("Skill not found"));
        if (!skill.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        skill.setName(dto.getName());
        skill.setLevel(dto.getLevel());
        return skillRepository.save(skill);
    }

    public void deleteSkill(Long id) {
        Skill skill = skillRepository.findById(id).orElseThrow(() -> new RuntimeException("Skill not found"));
        if (!skill.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        skillRepository.delete(skill);
    }
}
