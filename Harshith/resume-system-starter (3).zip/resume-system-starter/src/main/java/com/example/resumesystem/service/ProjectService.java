package com.example.resumesystem.service;

import com.example.resumesystem.dto.ProjectDTO;
import com.example.resumesystem.model.Project;
import com.example.resumesystem.model.User;
import com.example.resumesystem.repository.ProjectRepository;
import com.example.resumesystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    @Autowired
    private ProjectRepository projectRepository;

    @Autowired
    private UserRepository userRepository;

    private User getAuthenticatedUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Project createProject(ProjectDTO dto) {
        Project project = new Project();
        project.setTitle(dto.getTitle());
        project.setDescription(dto.getDescription());
        project.setStartDate(dto.getStartDate());
        project.setEndDate(dto.getEndDate());
        project.setUser(getAuthenticatedUser());
        return projectRepository.save(project);
    }

    public List<Project> getAllProjects() {
        return projectRepository.findByUser(getAuthenticatedUser());
    }

    public Project updateProject(Long id, ProjectDTO dto) {
        Project project = projectRepository.findById(id).orElseThrow(() -> new RuntimeException("Project not found"));
        if (!project.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        project.setTitle(dto.getTitle());
        project.setDescription(dto.getDescription());
        project.setStartDate(dto.getStartDate());
        project.setEndDate(dto.getEndDate());
        return projectRepository.save(project);
    }

    public void deleteProject(Long id) {
        Project project = projectRepository.findById(id).orElseThrow(() -> new RuntimeException("Project not found"));
        if (!project.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        projectRepository.delete(project);
    }
}
