package com.example.resumesystem.controller;

import com.example.resumesystem.dto.AchievementDTO;
import com.example.resumesystem.model.Achievement;
import com.example.resumesystem.service.AchievementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/achievements")
public class AchievementController {

    @Autowired
    private AchievementService achievementService;

    @PostMapping
    public ResponseEntity<Achievement> createAchievement(@RequestBody AchievementDTO dto) {
        return ResponseEntity.ok(achievementService.createAchievement(dto));
    }

    @GetMapping
    public ResponseEntity<List<Achievement>> getAllAchievements() {
        return ResponseEntity.ok(achievementService.getAllAchievements());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Achievement> updateAchievement(@PathVariable Long id, @RequestBody AchievementDTO dto) {
        return ResponseEntity.ok(achievementService.updateAchievement(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAchievement(@PathVariable Long id) {
        achievementService.deleteAchievement(id);
        return ResponseEntity.ok("Achievement deleted successfully");
    }
}
