package com.example.resumesystem.service;

import com.example.resumesystem.dto.CourseDTO;
import com.example.resumesystem.model.Course;
import com.example.resumesystem.model.User;
import com.example.resumesystem.repository.CourseRepository;
import com.example.resumesystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private UserRepository userRepository;

    private User getAuthenticatedUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Course createCourse(CourseDTO dto) {
        Course course = new Course();
        course.setTitle(dto.getTitle());
        course.setPlatform(dto.getPlatform());
        course.setCompletionDate(dto.getCompletionDate());
        course.setUser(getAuthenticatedUser());
        return courseRepository.save(course);
    }

    public List<Course> getAllCourses() {
        return courseRepository.findByUser(getAuthenticatedUser());
    }

    public Course updateCourse(Long id, CourseDTO dto) {
        Course course = courseRepository.findById(id).orElseThrow(() -> new RuntimeException("Course not found"));
        if (!course.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        course.setTitle(dto.getTitle());
        course.setPlatform(dto.getPlatform());
        course.setCompletionDate(dto.getCompletionDate());
        return courseRepository.save(course);
    }

    public void deleteCourse(Long id) {
        Course course = courseRepository.findById(id).orElseThrow(() -> new RuntimeException("Course not found"));
        if (!course.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        courseRepository.delete(course);
    }
}
