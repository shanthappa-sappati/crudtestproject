package com.example.resumesystem.dto;

import java.time.LocalDate;

public class CourseDTO {
    private String title;
    private String platform;
    private LocalDate completionDate;

    public CourseDTO() {}

    public CourseDTO(String title, String platform, LocalDate completionDate) {
        this.title = title;
        this.platform = platform;
        this.completionDate = completionDate;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPlatform() { return platform; }
    public void setPlatform(String platform) { this.platform = platform; }
    public LocalDate getCompletionDate() { return completionDate; }
    public void setCompletionDate(LocalDate completionDate) { this.completionDate = completionDate; }
}
