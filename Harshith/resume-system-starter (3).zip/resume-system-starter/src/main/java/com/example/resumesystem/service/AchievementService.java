package com.example.resumesystem.service;

import com.example.resumesystem.dto.AchievementDTO;
import com.example.resumesystem.model.Achievement;
import com.example.resumesystem.model.User;
import com.example.resumesystem.repository.AchievementRepository;
import com.example.resumesystem.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AchievementService {

    @Autowired
    private AchievementRepository achievementRepository;

    @Autowired
    private UserRepository userRepository;

    private User getAuthenticatedUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public Achievement createAchievement(AchievementDTO dto) {
        Achievement achievement = new Achievement();
        achievement.setTitle(dto.getTitle());
        achievement.setDescription(dto.getDescription());
        achievement.setDate(dto.getDate());
        achievement.setUser(getAuthenticatedUser());
        return achievementRepository.save(achievement);
    }

    public List<Achievement> getAllAchievements() {
        return achievementRepository.findByUser(getAuthenticatedUser());
    }

    public Achievement updateAchievement(Long id, AchievementDTO dto) {
        Achievement achievement = achievementRepository.findById(id).orElseThrow(() -> new RuntimeException("Achievement not found"));
        if (!achievement.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        achievement.setTitle(dto.getTitle());
        achievement.setDescription(dto.getDescription());
        achievement.setDate(dto.getDate());
        return achievementRepository.save(achievement);
    }

    public void deleteAchievement(Long id) {
        Achievement achievement = achievementRepository.findById(id).orElseThrow(() -> new RuntimeException("Achievement not found"));
        if (!achievement.getUser().equals(getAuthenticatedUser())) throw new RuntimeException("Unauthorized");
        achievementRepository.delete(achievement);
    }
}
